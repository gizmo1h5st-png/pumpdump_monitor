"""
Async REST-клиент Bybit v5 (public only)
Rate-limit-safe: используем один bulk-запрос тикеров
"""
import aiohttp
import asyncio
from config import BYBIT_REST

class BybitClient:
    def __init__(self):
        self.session: aiohttp.ClientSession | None = None
        self._lock = asyncio.Lock()

    async def start(self):
        self.session = aiohttp.ClientSession()

    async def close(self):
        if self.session:
            await self.session.close()

    async def _get(self, path: str, params: dict = None):
        async with self._lock:
            async with self.session.get(f"{BYBIT_REST}{path}", params=params or {}, timeout=aiohttp.ClientTimeout(total=15)) as r:
                data = await r.json()
                return data.get("result", {})

    async def get_linear_symbols(self):
        """Все перпетуальные пары"""
        res = await self._get("/v5/market/instruments-info", {"category": "linear"})
        return res.get("list", [])

    async def get_tickers(self):
        """Bulk тикеры всех linear (один запрос)"""
        res = await self._get("/v5/market/tickers", {"category": "linear"})
        return res.get("list", [])

    async def get_klines(self, symbol: str, interval: str, limit: int = 50):
        res = await self._get("/v5/market/kline", {
            "category": "linear",
            "symbol": symbol,
            "interval": interval,
            "limit": limit,
        })
        return res.get("list", [])  # [time, open, high, low, close, volume, turnover]

    async def get_recent_trade(self, symbol: str, limit: int = 100):
        res = await self._get("/v5/market/recent-trade", {
            "category": "linear",
            "symbol": symbol,
            "limit": limit,
        })
        return res.get("list", [])
